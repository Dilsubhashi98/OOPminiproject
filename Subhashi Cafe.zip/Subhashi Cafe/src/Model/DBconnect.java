
package Model;

import java.awt.Component;
import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;


public class DBconnect {
    
     public static Connection connect()
    {
        Connection conn = null;
     
        try {
            
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/subhacafe1","root","");
            
        } catch (Exception e) {
            Component nul = null;
            
            JOptionPane.showMessageDialog(nul, e);
                    
            
        }
        
        
        
        return conn;
    }
    
}
    

