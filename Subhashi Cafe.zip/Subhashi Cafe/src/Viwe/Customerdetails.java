
package Viwe;

import Model.DBconnect;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.jar.Attributes.Name;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import net.proteanit.sql.DbUtils;


public final class Customerdetails extends javax.swing.JFrame {

   java.sql.Connection conn = null;
   PreparedStatement pst = null;
   ResultSet rs = null;
    
    public Customerdetails() {
        
        initComponents ();
        conn = DBconnect.connect();
        tableload();
    }

    public void tabledata(){
        
         int r = ctablebox.getSelectedRow();
        
        String cid = ctablebox.getValueAt(r, 0).toString();
        String name = ctablebox.getValueAt(r, 1).toString();
        String gender = ctablebox.getValueAt(r, 2).toString();
        String pnumber = ctablebox.getValueAt(r, 3).toString();
        String address = ctablebox.getValueAt (r, 4).toString();
        
        customeridbox.setText(cid);
        cnamebox.setText(name);
        genderbox.setSelectedItem(gender);
        cphonenumbox.setText(pnumber);
        caddressbox.setText(address);
       
    }
    public void tableload(){
    
        try {
            
            String sql = "SELECT ccustomerid,cname,cgender,cnumber,caddress FROM cusdetails";
            PreparedStatement pst = conn.prepareStatement(sql);
            
            rs = pst.executeQuery();
            ctablebox.setModel(DbUtils.resultSetToTableModel(rs));
            
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        
    }
    
    
    
   public void update(){
        String Id= customeridbox.getText();
        String Name = cnamebox.getText();
        String Gender = (String) genderbox.getSelectedItem();
        String Pnumber = cphonenumbox.getText();
        String Address = caddressbox.getText();
        
       try{
           
           String sql = "UPDATE cusdetails SET  cname=?, cgender=?, cnumber= ?, caddress= ? WHERE ccustomerid=?";
           pst = conn.prepareStatement(sql);
           
          
           pst.setString(1, Name);
           pst.setString(2, Gender);
           pst.setString(3, Pnumber);
           pst.setString(4, Address);
           pst.setString(5, Id);
           
           pst.executeUpdate();
           JOptionPane.showMessageDialog(null, "Update successful!");
       } catch (SQLException e){
       
           JOptionPane.showMessageDialog(null, "Update failed:" + e.getMessage());
      
           e.printStackTrace();
       }
               
               
    }

    

    
            
            
    @SuppressWarnings("unchecked")
    
        // Your initComponents method
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jToolBar1 = new javax.swing.JToolBar();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        ctablebox = new javax.swing.JTable();
        jPanel5 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        cnamebox = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        cphonenumbox = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        caddressbox = new javax.swing.JTextField();
        cinsertbtn = new javax.swing.JButton();
        cdeletebtn = new javax.swing.JButton();
        backbtn1 = new javax.swing.JButton();
        cupdatebtn = new javax.swing.JButton();
        cnextbtn = new javax.swing.JButton();
        genderbox = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        customeridbox = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();

        jToolBar1.setRollover(true);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(51, 255, 153));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(102, 51, 0));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ctablebox.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "customer id", "name", "gender", "number", "addresst"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        ctablebox.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ctableboxMouseClicked(evt);
            }
        });
        ctablebox.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                ctableboxKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(ctablebox);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 60, 350, 190));

        jPanel5.setBackground(new java.awt.Color(153, 102, 0));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel3.setText("Customer Name");
        jPanel5.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, -1, -1));
        jPanel5.add(cnamebox, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 70, 80, -1));

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel4.setText("Gender");
        jPanel5.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, -1, 20));

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel5.setText("Contact Number");
        jPanel5.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, -1, 20));
        jPanel5.add(cphonenumbox, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 130, 80, -1));

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel6.setText("Address");
        jPanel5.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, -1, -1));
        jPanel5.add(caddressbox, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 160, 80, -1));

        cinsertbtn.setBackground(new java.awt.Color(51, 102, 255));
        cinsertbtn.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        cinsertbtn.setText("Insert");
        cinsertbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cinsertbtnActionPerformed(evt);
            }
        });
        jPanel5.add(cinsertbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 210, -1, -1));

        cdeletebtn.setBackground(new java.awt.Color(0, 102, 255));
        cdeletebtn.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        cdeletebtn.setText("Delete");
        cdeletebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cdeletebtnActionPerformed(evt);
            }
        });
        jPanel5.add(cdeletebtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 210, -1, -1));

        backbtn1.setBackground(new java.awt.Color(204, 0, 0));
        backbtn1.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        backbtn1.setText("Back");
        backbtn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backbtn1ActionPerformed(evt);
            }
        });
        jPanel5.add(backbtn1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 250, -1, -1));

        cupdatebtn.setBackground(new java.awt.Color(0, 102, 0));
        cupdatebtn.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        cupdatebtn.setText("Update");
        cupdatebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cupdatebtnActionPerformed(evt);
            }
        });
        jPanel5.add(cupdatebtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 250, -1, -1));

        cnextbtn.setBackground(new java.awt.Color(0, 102, 255));
        cnextbtn.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        cnextbtn.setText("Next");
        cnextbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cnextbtnActionPerformed(evt);
            }
        });
        jPanel5.add(cnextbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 250, -1, -1));

        genderbox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Male", "Female" }));
        jPanel5.add(genderbox, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 100, 80, -1));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel2.setText("Customer Id");
        jPanel5.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 40, -1, -1));
        jPanel5.add(customeridbox, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 40, 80, -1));

        jPanel1.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 230, 300));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        jLabel1.setText("Customer Details");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 10, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 620, 300));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cinsertbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cinsertbtnActionPerformed
       
        int cId;
        String cName;
        String cGender;
        int cContactnumber;
        String cAddress;
        
        try {
        
        cId = Integer.parseInt(customeridbox.getText());
        cName = cnamebox.getText();
        cGender = genderbox.getSelectedItem().toString();
        cContactnumber = Integer.parseInt(cphonenumbox.getText());
        cAddress = caddressbox.getText();
        
            
            String sql = "INSERT INTO cusdetails(ccustomerid,cname,cgender,cnumber,caddress)VALUES (?,?,?,?,?)";
            PreparedStatement pst = conn.prepareStatement(sql);
            
            
            pst.setInt(1,cId);
            pst.setString(2, cName);
            pst.setString(3, cGender);
            pst.setInt(4, cContactnumber);
            pst.setString(5, cAddress);
            
            pst.executeUpdate();
            
        
            JOptionPane.showMessageDialog(null,"Record inserted successfully");
            
        } catch (NumberFormatException e){
            JOptionPane.showMessageDialog(null,"Invalid input format:" + e.getMessage());
        } catch (SQLException e){
            JOptionPane.showMessageDialog(null,"Database error:" + e.getMessage());
        
       }
        
         tableload();
        
    }//GEN-LAST:event_cinsertbtnActionPerformed

    private void ctableboxMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ctableboxMouseClicked
        // TODO add your handling code here:
        tabledata();
    }//GEN-LAST:event_ctableboxMouseClicked

    private void ctableboxKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ctableboxKeyReleased
        // TODO add your handling code here:
        tabledata();
    }//GEN-LAST:event_ctableboxKeyReleased

    private void cupdatebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cupdatebtnActionPerformed

        update();
        tableload();
        
        
    }//GEN-LAST:event_cupdatebtnActionPerformed

    private void cdeletebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cdeletebtnActionPerformed

        int check = JOptionPane.showConfirmDialog(null, "Do you want to delete?");
        
        if (check == 0){
           
            String ccustomerid = customeridbox.getText();
            try{
            String sql = "DELETE FROM cusdetails WHERE ccustomerid=? ";
            pst = conn.prepareStatement(sql);
            pst.setString(1, ccustomerid);
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "Deleted");
        } catch (SQLException e){
                JOptionPane.showMessageDialog(null, "Delete failed:" + e.getMessage());
                
                }finally{
                        try{
                            if (pst != null) pst.close();
                        }catch (SQLException e){
                        }
            }
            
    }//GEN-LAST:event_cdeletebtnActionPerformed

        tableload();
    }
    private void cnextbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cnextbtnActionPerformed
        Cafedetails subha = new Cafedetails();
        subha.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_cnextbtnActionPerformed

    private void backbtn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backbtn1ActionPerformed

        login sc = new login();
        sc.setVisible(true);
        this.dispose();


        
    }//GEN-LAST:event_backbtn1ActionPerformed

    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Customerdetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Customerdetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Customerdetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Customerdetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Customerdetails().setVisible(true);
      
}
        });
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backbtn1;
    private javax.swing.JTextField caddressbox;
    private javax.swing.JButton cdeletebtn;
    private javax.swing.JButton cinsertbtn;
    private javax.swing.JTextField cnamebox;
    private javax.swing.JButton cnextbtn;
    private javax.swing.JTextField cphonenumbox;
    private javax.swing.JTable ctablebox;
    private javax.swing.JButton cupdatebtn;
    private javax.swing.JTextField customeridbox;
    private javax.swing.JComboBox<String> genderbox;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JToolBar jToolBar1;
    // End of variables declaration//GEN-END:variables
}
